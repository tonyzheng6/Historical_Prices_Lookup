Csci 394 Java: 	Project 3: Historical Prices HashMapAuthor: 	Tony ZhengCreated on: 	January 23, 2015
Description: 	Creates a HashMap from the file specified in the command line argument and		
		a GUI for the user to enter the date as the key to lookup the values in 		
		the HashMapBuild with: 	Eclipse or using the following commands			- To compile: HistoricalPrices.java TestMap.java Values.java			- To run: java HistoricalPrices ‘Filename’Main file:	HistoricalPrices.javaFiles included: HistoricalPrices.java, TestMap.java Values.javaSpecial Thanks: Ameya Pednekar